﻿using UnityEngine;
using System.Collections;

//button message receiver
// go to Unity Level 2 (Color Matching Puzzle Game)
public class Title_3Game : MonoBehaviour {
	void OnPressed(){
		Application.LoadLevel(2);
	}
}
