﻿using UnityEngine;
using System.Collections;

//button message receiver
// go to Unity Level 1 (Three Matching Puzzle Game)
public class Title_1Game : MonoBehaviour {
	void OnPressed(){
		Application.LoadLevel(1);
	}
}
