﻿using UnityEngine;
using System.Collections;

//button message receiver
// go to Unity Level 3 (Link Matching Puzzle Game)
public class Title_2Game : MonoBehaviour {
	void OnPressed(){
		Application.LoadLevel(3);
	}
}
